/*-------------------------------------------------------------------------------------------------------------------------
    The following is line code proprietary to the Holon Group - who are collectively, Stephen Dean Wareham Jr., Keith Schonn,
    Jenascia Drew and Benjamin Quimby.  The Holon Group is creating this website for potential commercial use - and all parties
agree that it is the Holon Groups right to do so if they so desire.

    Stephen D Wareham Jr. for The Holon Group - All rights reserved.

    CLIENT BUILD: SOLID CHOICE WEBSITE - WENDY RADER
Alpha Version 1.0 - 26 Feb 2025  17:00  - index.html - styles.css - logo.png
**Images file added to project - absolute root for images = /images/filename.jpeg  **
/images/background.png **
/images/colorwheel.jpg **
/images/logo.jpg	   **
- Fully commented and edited.  HTML Scaling done.  CSS is go for alpha. JavaScript not yet complete. Placeholders only.
---------------------------------------------------------------------------------------------------------------------------
    NEXT STEPS:
    1) Implement version control via GitHub.
2) Check into BlueHost to see if I (sw) can attach a free domain name to my account.  If not - will find a freeWebHost.
3) Connect to project via FTP.
4) Build authorizations for you all to be able to connect as well.
5) Sleep, maybe.
----------------------------------------------------------------------------------------------------------------------------*/
/* Scripts.js - This file handles interactive functionality for the website */

document.addEventListener("DOMContentLoaded", function () {
    /* Smooth Scrolling for Navigation Links */
    document.querySelectorAll("nav ul li a").forEach(anchor => {
        anchor.addEventListener("click", function (event) {
            event.preventDefault(); // Prevent default link behavior
            const targetId = this.getAttribute("href").substring(1); // Get the section ID
            document.getElementById(targetId).scrollIntoView({
                behavior: "smooth" // Smooth scrolling animation
            });
        });
    });

    /* Hero Section Button - Scroll to About Section */
    document.getElementById("learn-more")?.addEventListener("click", function () {
        document.getElementById("about").scrollIntoView({ behavior: "smooth" });
    });

    /* Simple Live Chat Toggle - Placeholder for Future Integration */
    const chatButton = document.getElementById("start-chat");
    chatButton?.addEventListener("click", function () {
        alert("Live chat feature coming soon!"); // Simulates a chat feature
    });

    /* Login Form Validation */
    document.getElementById("login-form")?.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevents form from submitting normally
        const username = document.getElementById("username").value.trim(); // Gets the username input
        const password = document.getElementById("password").value.trim(); // Gets the password input

        if (username === "" || password === "") { // Checks if fields are empty
            alert("Please enter both username and password."); // Alerts the user
            return;
        }

        alert("Login successful (placeholder logic). Redirecting..."); // Simulated login success message
    });
});
